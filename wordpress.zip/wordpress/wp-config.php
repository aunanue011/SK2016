<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', 'wordpress');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8mb4');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'nmZI1-1kb-J%yhBh/. eUy.ZaetQVN0p1yWk}Xz^`4RnEo)]hc?(}.*[o)F<?)$F');
define('SECURE_AUTH_KEY', ':hq e4$*8Ov}6p.MOg.s6d+HEuo%6.XcF3(bRN9OnGPVUWKaBO$`8+ynsq@+Trb[');
define('LOGGED_IN_KEY', ',^|Z{c Oy7&W6rVuG_Wgz1p+$-5@sC1evxsZa%sT1wP~&}uf7A$,n}~M#rU{bDed');
define('NONCE_KEY', 'tz[U!J?SrA3-k<dw3#&P/z~u;uhN@G4e,v}qw{7i3%Yf2fhf<+^4;)eUR-~#=wW&');
define('AUTH_SALT', '|6Kz!@&sM0O/Z{06s&E*,^(3|hPMB7|C0nm^+:kIT.3 j31})k+z6M&+,pn.$(dB');
define('SECURE_AUTH_SALT', '=Li>$]@o-a&G%8a9.(2mg:;k#*Egx{H&a>yPk<:c[%~-/av N*@kMAl!7v9RJL`w');
define('LOGGED_IN_SALT', 'oEfj{HU^?O-Bj@Fy=;puiFsMjX^/J;>e^.i0Y &-/oJ?2ArxxN|X;JcLj7?7Z|0t');
define('NONCE_SALT', 'Z54mX:0+gHY:EKaw.co>Z(|%v>G6h>aVZO66:~IOs,y=bf-_S0?waU_8u!{P;0i_');

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'wp_';


/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

